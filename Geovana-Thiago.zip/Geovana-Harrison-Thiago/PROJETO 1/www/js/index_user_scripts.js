/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  #btcadastre */
    $(document).on("click", "#btcadastre", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_form"); 
         return false;
    });
    
        /* button  #Home */
    $(document).on("click", "#Home", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#maincontent"); 
         return false;
    });
    
        /* button  Go */
    $(document).on("click", ".uib_w_14", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_sucesso"); 
         return false;
    });
    
        /* button  Brasital */
    $(document).on("click", ".uib_w_23", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_56_72"); 
         return false;
    });
    
        /* button  Fatec SR */
    $(document).on("click", ".uib_w_24", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_fatec"); 
         return false;
    });
    
        /* button  Brasital */
    
    
        /* button  Fatec SR */
    $(document).on("click", ".uib_w_30", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_fatec"); 
         return false;
    });
    
        /* button  Brasital */
    $(document).on("click", ".uib_w_29", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#uib_page_brasital"); 
         return false;
    });
    
        /* button  .uib_w_34 */
    $(document).on("click", ".uib_w_34", function(evt)
    {
         /*global activate_page */
         activate_page("#uib_page_proximo"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
