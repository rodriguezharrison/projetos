/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  #BotaoPesquisa */
    
    
        /* button  #botao_como_funciona */
    
    
        /* button  #botao_como_funciona */
    
    
        /* button  #proxima_1 */
    $(document).on("click", "#proxima_1", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_3"); 
         return false;
    });
    
        /* button  #proxima_2 */
    $(document).on("click", "#proxima_2", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_4"); 
         return false;
    });
    
        /* button  #proxima_3 */
    $(document).on("click", "#proxima_3", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_5"); 
         return false;
    });
    
        /* button  #proxima_4 */
    $(document).on("click", "#proxima_4", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_6"); 
         return false;
    });
    
        /* button  #proxima_5 */
    $(document).on("click", "#proxima_5", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_7"); 
         return false;
    });
    
        /* button  #proxima_6 */
    $(document).on("click", "#proxima_6", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_8"); 
         return false;
    });
    
        /* button  #proxima_7 */
    $(document).on("click", "#proxima_7", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_9"); 
         return false;
    });
    
        /* button  #resultado */
    $(document).on("click", "#resultado", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_10"); 
         return false;
    });
    
        /* button  #botao_voltar */
    $(document).on("click", "#botao_voltar", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_10"); 
         return false;
    });
    
        /* button  #baixo */
    $(document).on("click", "#baixo", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#resultado_1"); 
         return false;
    });
    
        /* button  #home */
    $(document).on("click", "#home", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#maincontent"); 
         return false;
    });
    
        /* button  #BotaoPesquisa */
    $(document).on("click", "#BotaoPesquisa", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste_2"); 
         return false;
    });
    
        /* button  #botao_como_funciona */
    $(document).on("click", "#botao_como_funciona", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#inicio_teste"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
